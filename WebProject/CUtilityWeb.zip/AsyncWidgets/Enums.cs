﻿using System;
using System.Collections.Generic;
using System.Web;

namespace WebProject.AsyncWidgets.UI.Widgets
{
    public enum LazyLoadType
    {
        Anonymous, Sessioned, Both
    }
}