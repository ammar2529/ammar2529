﻿
using System.Web.UI;


namespace WebProject.eForms.Web.UI
{
    public class ScriptBlock : Control
    {
        public ScriptBlock()
        {
            
        }
    }
    public class CodeBlock : Control
    {
        public CodeBlock()
        {
        }
    }
}