﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;

namespace WebProject.eForms.Web.UI
{

    public class PWCLightPage : Control
    {

    }
}

namespace WebProject.eForms.Web.UI.Page
{

    public class PWCLightPage : System.Web.UI.Page
    {

    }
}
namespace WebProject.eForms.Web.UI.Interface
{

    interface PWCLightPage 
    {

    }
}
namespace PWC.PresentationServices.Web.UI.WebControls
{ 

}
namespace PWC.PresentationServices.Web.UI.Common
{

}